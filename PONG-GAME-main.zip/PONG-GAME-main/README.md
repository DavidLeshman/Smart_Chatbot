# PONG-GAME
 👉🏻 It is a simple Pong Game in Python using Pygame.
 
---

<p align="center"> <b> 👉🏻 Created Pong Game 👈🏻 <b> </p>
 
<p align="center"><a href='https://github.com/Amey-Thakur/PONG-GAME', style='color: greenyellow;'> ✌🏻 Back To Repository ✌🏻</p>
